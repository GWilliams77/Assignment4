﻿//Vu Le and Gerald Williams
//Fall 2016
//Assigment 3
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment3
{
    public partial class frmAssigment3 : Form
    {
        //Global Constant and variable
        const decimal decTAX_RATE = 0.087m;
        private decimal decTOTAL; // 0.0m
        private decimal decTOTAL_DUE; // 0.0m
        public frmAssigment3()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            //Close the form
            this.Close();
        }
        
               
        private void btnAdd_Click(object sender, EventArgs e)
        {
            //Try/Catch for errors in calculations
            try
            {
                //Local variable
                decimal decQuantity, decPrice;
                //Convert text to decimal
                decQuantity = Convert.ToDecimal(txtQuantity.Text);
                decPrice = Convert.ToDecimal(txtPrice.Text);
                //Calculation (quantity times price) then multiply with 8.7% tax rate
                decTOTAL = (decQuantity * decPrice) * decTAX_RATE;
                //Caculation for total of the items including tax.          
                decTOTAL = (decQuantity * decPrice) + decTOTAL;
                //Accumulate for total due.
                decTOTAL_DUE += decTOTAL;
                //Convert from decimal back to text to show user the final total due
                txtTotal.Text = decTOTAL_DUE.ToString("c");
                //Clear description, quantity, price then focus back to description
                txtDescription.Clear();
                txtQuantity.Clear();
                txtPrice.Clear();
                txtDescription.Focus();
            }            
            // Catch All, format wrong
            catch (FormatException)
            {
                 MessageBox.Show("Non-Numeric", "Bad Input");
            }
            // Catch, data size too large
            catch (OverflowException)
            {
                 MessageBox.Show("Huge", "Bad Input");                        
            }
        }
        
        private void txtDescription_TextChanged(object sender, EventArgs e)
        {
            //Disable the customer group box when enter text in description
            grpCustomer.Enabled = false;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            //reset the accumulator back to 0
            decTOTAL = 0.0m;
            decTOTAL_DUE = 0.0m;
            //Clear all data and focus back to Name
            txtName.Clear();
            txtStreet.Clear();
            txtCity.Clear();
            mskState.Clear();
            mskZip.Clear();
            txtDescription.Clear();
            txtQuantity.Clear();
            txtPrice.Clear();
            txtTotal.Clear();
            grpCustomer.Enabled = true;
            txtName.Focus();
        }
    }
}
